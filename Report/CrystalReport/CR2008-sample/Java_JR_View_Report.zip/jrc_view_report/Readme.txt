________________________________________________________________ 

Business Objects Support - jrc_view_report

Web Site: 
http://www.businessobjects.com

Support Website:
http://support.businessobjects.com

________________________________________________________________ 

PRODUCT

This Java Server Pages (JSP) sample application is for use only with the Crystal Reports (CR) Java Reporting Component (JRC). 

________________________________________________________________ 

DESCRIPTION

This sample demonstrates how to launch a report in the zero-client DHTML viewer (CrystalReportViewer).  

________________________________________________________________ 

FILES
		
jrc_view_report.jsp 
jrc_view_report.rpt
CrystalReportViewer.jsp

________________________________________________________________ 

INSTALLATION

1. Setup an application context on your application server to host a web application. For assistance with setting up and deploying a web application using the Java Reporting Component, refer to this whitepaper:

http://support.businessobjects.com/communityCS/TechnicalPapers/cr_xi_r2_jrc_deployment.pdf

2. Extract the contents of this folder into your web application's context root.

3. In a browser window, launch the file jrc_view_report.jsp as follows: 

http://<computer name>:<port number>/<web app>/jrc_view_report.jsp 

________________________________________________________________

Last updated December 2005
________________________________________________________________ 