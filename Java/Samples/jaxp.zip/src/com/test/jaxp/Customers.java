package com.test.jaxp;

import java.util.ArrayList;
import java.util.List;

import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlElementWrapper;
import javax.xml.bind.annotation.XmlElements;
import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement(name = "customers")
public class Customers
{
	List<Customer>	records	= new ArrayList<Customer>();

	//@XmlElementWrapper
	@XmlElement(name = "customer", type = Customer.class)
	public List<Customer> getRecords()
	{
		return records;
	}

	public void setRecords(List<Customer> records)
	{
		this.records = records;
	}
}