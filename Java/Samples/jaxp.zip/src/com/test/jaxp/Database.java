package com.test.jaxp;

import java.util.ArrayList;
import java.util.List;

import javax.xml.bind.annotation.XmlRootElement;


@XmlRootElement
public class Database
{
	List<Data>	records	= new ArrayList<Data>();

	public List<Data> getRecords()
	{
		return records;
	}

	public void setRecords(List<Data> records)
	{
		this.records = records;
	}
}