package com.test.jaxp;

import java.io.File;
import java.io.FileWriter;
import java.io.StringReader;

import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBException;
import javax.xml.bind.Marshaller;
import javax.xml.bind.Unmarshaller;

//Convert Object to XML
public class JAXBExample
{
	public void Object2XML()
	{
		Customer customer1 = new Customer();
		customer1.setId(100);
		customer1.setName("mkyong");
		customer1.setAge(29);
		
		Customer customer2 = new Customer();
		customer2.setId(100);
		customer2.setName("mkyong");
		customer2.setAge(29);
		
		Customers customers = new Customers();
		customers.getRecords().add(customer1);
		customers.getRecords().add(customer2);

		try
		{

			File file = new File("out\\file.xml");
			JAXBContext jaxbContext = JAXBContext.newInstance(Customers.class);
			Marshaller jaxbMarshaller = jaxbContext.createMarshaller();

			// output pretty printed
			jaxbMarshaller.setProperty(Marshaller.JAXB_FORMATTED_OUTPUT, true);

			jaxbMarshaller.marshal(customers, file);
			jaxbMarshaller.marshal(customers, System.out);

		}
		catch (JAXBException e)
		{
			e.printStackTrace();
		}
	}

	public void XML2Object()
	{
		try
		{

			// File file = new File("in\\data.xml");
			StringReader reader = new StringReader(
					"<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"yes\"?><customers><customer id=\"100\"><age>29</age><name>wakkir</name></customer><customer id=\"130\"><age>39</age><name>wa3kkir</name></customer></customers>");

			JAXBContext jaxbContext = JAXBContext.newInstance(Customers.class);
			Unmarshaller jaxbUnmarshaller = jaxbContext.createUnmarshaller();

			// Customer customer = (Customer) jaxbUnmarshaller.unmarshal(file);
			Customers customer = (Customers) jaxbUnmarshaller.unmarshal(reader);

			System.out.println(customer.getRecords());

		}
		catch (JAXBException e)
		{
			e.printStackTrace();
		}
	}

	public void test1()
	{
		Data data1 = new Data();
		data1.setName("Peter");
		data1.setAddress("Cologne");

		Data data2 = new Data();
		data2.setName("Mary");
		data2.setAddress("Hamburg");

		Database database = new Database();
		database.getRecords().add(data1);
		database.getRecords().add(data2);

		try
		{
			JAXBContext context = JAXBContext.newInstance(Database.class);
			Marshaller marshaller = context.createMarshaller();
			marshaller.setProperty(Marshaller.JAXB_FORMATTED_OUTPUT, true);
			marshaller.marshal(database, new FileWriter("out\\test.xml"));
		}
		catch (Exception e)
		{
			// TODO: handle exception
		}
	}

	public static void main(String[] args)
	{
		System.out.println("Starting...");
		JAXBExample jaxp = new JAXBExample();
		 //jaxp.Object2XML();
		jaxp.XML2Object();
		//jaxp.test1();

		System.out.println("Ended...");

	}
}
