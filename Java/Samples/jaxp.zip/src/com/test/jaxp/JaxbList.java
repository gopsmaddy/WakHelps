package com.test.jaxp;

import java.util.List;

import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement(name = "customers")
public class JaxbList<T>
{
	protected List<T>	records;

	public JaxbList()
	{
	}

	public JaxbList(List<T> records)
	{
		this.records = records;
	}

	//@XmlElementWrapper
	//@XmlElements({ @XmlElement(name = "customer", type = Customer.class)})//, @XmlElement(name = "boy", type = Boy.class) })
	@XmlElement(name = "customer")
	public List<T> getRecords()
	{
		return records;
	}
}
