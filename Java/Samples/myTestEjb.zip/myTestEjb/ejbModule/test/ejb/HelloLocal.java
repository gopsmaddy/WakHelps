package test.ejb;

import javax.ejb.Local;

@Local
public interface HelloLocal extends IHello
{

}
