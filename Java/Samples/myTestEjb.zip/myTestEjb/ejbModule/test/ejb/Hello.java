package test.ejb;

import javax.ejb.Stateless;

import test.object.ChileObject;
import test.object.RootObj;

/** Session Bean implementation class Hello */
@Stateless
public class Hello implements HelloRemote, HelloLocal
{
	ChileObject cobj=new ChileObject();
	
	public String sayHello(String name)
	{
		System.out.println("Name is : "+name);		
		return "Hellox " + name;
	}
	
	public ChileObject sayHello(RootObj robj,String name)
	{
		System.out.println("Name is : "+name);
		System.out.println("Id is : "+robj.getId());
		cobj.setId("MyID is:"+robj.getId());
		cobj.setName("MYName is : "+name);
		return cobj;
	}

}
