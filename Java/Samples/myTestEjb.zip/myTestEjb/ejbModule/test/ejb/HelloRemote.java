package test.ejb;

import javax.ejb.Remote;

@Remote
public interface HelloRemote extends IHello
{

}
