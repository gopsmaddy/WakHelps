package test.ejb;

import java.io.Serializable;

import test.object.ChileObject;
import test.object.RootObj;

public interface IHello extends Serializable
{	
	public String sayHello(String name);
	
	public ChileObject sayHello(RootObj robj,String name);
}
