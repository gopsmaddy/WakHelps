package test.object;

import java.io.Serializable;

public class RootObj implements Serializable
{
	private static final long	serialVersionUID	= 2343324234243L;
	
	private String id;

	public String getId()
	{
		return id;
	}

	public void setId(String id)
	{
		this.id = id;
	}

	@Override
	public String toString()
	{
		return "RootObj [id=" + id + "]";
	}
	
  
	
}
