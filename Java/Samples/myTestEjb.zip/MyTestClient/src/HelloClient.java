import java.util.Properties;

import javax.naming.InitialContext;
import javax.naming.NamingException;

import test.ejb.HelloRemote;
import test.object.ChileObject;
import test.object.RootObj;

/*
 * A simple client for accessing an EJB.
 */

public class HelloClient
{
	public static void main(String[] args)
	{
		System.out.println("client started...");
		try
		{
			Properties props = new Properties();
      //props.setProperty("java.naming.factory.initial","org.jnp.interfaces.NamingContextFactory");
      //props.setProperty("java.naming.factory.url.pkgs", "org.jboss.naming");
      //props.setProperty("java.naming.provider.url", "127.0.0.1:1099");     
			
			InitialContext ctx = new InitialContext(props);
      HelloRemote bean = ( HelloRemote) ctx.lookup("test.ejb.HelloRemote");
      String say=bean.sayHello("Wakkir");
			System.out.println(say);
			System.out.println("******");
			RootObj rObj=new RootObj();
			rObj.setId("344");
			ChileObject cObj=bean.sayHello(rObj,"Mohamed");
			System.out.println(cObj);
			/*
			Properties props = new Properties();
      props.setProperty("java.naming.factory.initial","org.jnp.interfaces.NamingContextFactory");
      props.setProperty("java.naming.factory.url.pkgs", "org.jboss.naming");
      props.setProperty("java.naming.provider.url", "127.0.0.1:1099");        
      
			// Initial context properties are set in the jndi.properties file
			// 1. Retrieve remote interface using a JNDI lookup
			Context context = new InitialContext(props);

			// Lookup the HelloHome object. The reference is retrieved from the
			// application-local context (java:comp/env). The variable is
			// specified in the application-client.xml).
			Object homeObject = context.lookup("java:comp/env/Hello");//

			// 2. Narrow the reference to HelloHome. Since this is a remote // object, use the PortableRemoteObject.narrow
			// method.
			//HelloHome home = (HelloHome) PortableRemoteObject.narrow(homeObject, HelloHome.class);

			// 3. Create the remote object and narrow the reference to Hello.
			//Hello remote = (Hello) PortableRemoteObject.narrow(home.create(), Hello.class);

			// 4. Invoke a business method on the remote interface reference.
			//System.out.println(remote.sayHello("James Earl"));
			*/
		}
		catch (NamingException e)
		{
			System.err.println("NamingException: " + e.getMessage());
		}
		//catch (RemoteException e)
		//{
		//	System.err.println("RemoteException: " + e.getMessage());
		//}
		//catch (CreateException e)
		//{
		//	System.err.println("FinderException: " + e.getMessage());
		//}
	}
}