package com.wakkir.web.context;

import com.wakkir.ejb.IMyTestEjbLocal;
import com.wakkir.ejb.MyTestEjb;

import javax.ejb.EJB;
import javax.servlet.ServletContextEvent;
import javax.servlet.ServletContextListener;

/**
 * Created with IntelliJ IDEA.
 * User: wakkir
 * Date: 17/11/12
 * Time: 22:55
 * To change this template use File | Settings | File Templates.
 */
public class MyWebContextListener implements ServletContextListener
{
    @EJB
    IMyTestEjbLocal myeTestEjb;

    public void contextInitialized(ServletContextEvent servletContextEvent)
    {
        System.out.println("MyWebContextListener::contextInitialized.......");
        System.out.println("MyWebContextListener::calling myeTestEjb......."+myeTestEjb.sayHello("Wakkir"));
    }

    public void contextDestroyed(ServletContextEvent servletContextEvent)
    {
        System.out.println("MyWebContextListener::contextDestroyed.......");
    }
}
