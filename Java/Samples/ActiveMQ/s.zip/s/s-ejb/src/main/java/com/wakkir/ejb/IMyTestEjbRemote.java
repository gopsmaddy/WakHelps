package com.wakkir.ejb;

import javax.ejb.Remote;

/**
 * Created with IntelliJ IDEA.
 * User: wakkir
 * Date: 17/11/12
 * Time: 23:14
 * To change this template use File | Settings | File Templates.
 */
@Remote
public interface IMyTestEjbRemote
{
    public String sayHello(String name);
}

