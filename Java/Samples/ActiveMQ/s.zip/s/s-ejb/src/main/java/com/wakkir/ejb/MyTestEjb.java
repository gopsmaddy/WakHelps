package com.wakkir.ejb;

import javax.ejb.Stateless;

/**
 * Created with IntelliJ IDEA.
 * User: wakkir
 * Date: 17/11/12
 * Time: 23:12
 * To change this template use File | Settings | File Templates.
 */
@Stateless
public class MyTestEjb  implements IMyTestEjbLocal,IMyTestEjbRemote
{

    public String sayHello(String name)
    {
        return "Hello "+name+" !!!!";
    }
}
