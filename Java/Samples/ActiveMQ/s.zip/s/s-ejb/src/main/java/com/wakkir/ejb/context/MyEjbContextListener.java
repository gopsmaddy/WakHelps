package com.wakkir.ejb.context;

import com.wakkir.test2.SpringPublisher;
import org.springframework.beans.factory.xml.XmlBeanFactory;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.FileSystemXmlApplicationContext;
import org.springframework.core.io.ClassPathResource;
import org.springframework.web.context.WebApplicationContext;
import org.springframework.web.context.support.WebApplicationContextUtils;

import javax.servlet.ServletContextEvent;
import javax.servlet.ServletContextListener;

/**
 * Created with IntelliJ IDEA.
 * User: wakkir
 * Date: 17/11/12
 * Time: 22:55
 * To change this template use File | Settings | File Templates.
 */
public class MyEjbContextListener implements ServletContextListener
{
    public void contextInitialized(ServletContextEvent servletContextEvent)
    {
        System.out.println("MyEjbContextListener::contextInitialized.......");

        String path=servletContextEvent.getServletContext().getRealPath("WEB-INF");

        FileSystemXmlApplicationContext context = new FileSystemXmlApplicationContext(path+"/spring/spring-context.xml");
        //ClassPathResource res = new ClassPathResource("spring-context.xml");
        //XmlBeanFactory context = new XmlBeanFactory(res);
        //WebApplicationContext context = WebApplicationContextUtils.getRequiredWebApplicationContext(servletContextEvent.getServletContext());
        SpringPublisher publisher = (SpringPublisher)context.getBean("stockPublisher");
        publisher.start();
    }




    public void contextDestroyed(ServletContextEvent servletContextEvent)
    {
        System.out.println("MyEjbContextListener::contextDestroyed.......");
    }
}
