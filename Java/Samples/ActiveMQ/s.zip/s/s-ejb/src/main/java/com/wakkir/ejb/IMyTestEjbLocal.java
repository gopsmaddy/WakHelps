package com.wakkir.ejb;

import javax.ejb.Local;

/**
 * Created with IntelliJ IDEA.
 * User: wakkir
 * Date: 17/11/12
 * Time: 23:13
 * To change this template use File | Settings | File Templates.
 */
@Local
public interface IMyTestEjbLocal
{
    public String sayHello(String name);
}
